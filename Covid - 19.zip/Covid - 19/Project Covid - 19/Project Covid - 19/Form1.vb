﻿Public Class Form1
    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        If RadioButton1.Checked = True Then
            jk = RadioButton1.Text
        Else
            jk = RadioButton2.Text
        End If

        ya = CheckedListBox1.CheckedItems.Count
        yb = CheckedListBox2.CheckedItems.Count
        yc = CheckedListBox3.CheckedItems.Count

        ta = 10 - ya
        tb = 6 - yb
        tc = 5 - yc

        y = ya + yb + yc
        t = ta + tb + tc

        If y >= 0 And y <= 8 Then
            hasil = "Rendah"
            Label10.Text = "Resiko Rendah"
        ElseIf y >= 8 And y <= 15 Then
            hasil = "Sedang"
            Label10.Text = "Resiko Sedang"
        Else
            hasil = "Tinggi"
            Label10.Text = "Resiko Tinggi"
        End If
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        sqlnya = "insert into tb_survey(NIS,Nama,Umur,Jenis_Kelamin,Jumlah_Checklist,Risiko)values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & jk & "','" & y & "','" & hasil & "')"
        Call jalan()
        Call panggildata()
        Form3.Show()
    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click

    End Sub
End Class
